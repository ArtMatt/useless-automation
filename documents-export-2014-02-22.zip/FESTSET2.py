import masterca
import os
import auto
import time

masterca.sshPhone(2)
