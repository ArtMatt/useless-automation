import masterca
import auto
import os
import time

masterca.cycleFestFirst()
