import masterca

masterca.cycleGBA()
