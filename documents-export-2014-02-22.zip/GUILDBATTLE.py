import masterca
import time
import auto
import os

masterca.cycleGBA()
