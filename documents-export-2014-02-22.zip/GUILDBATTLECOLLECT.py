import masterca
import auto
import time
import os

masterca.GBcollect()
